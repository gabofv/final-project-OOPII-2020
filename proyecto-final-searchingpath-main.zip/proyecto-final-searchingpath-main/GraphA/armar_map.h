#include <fstream>
#include <string>
using namespace std;

char** armar_mapa(string& archivo);